﻿using System;

namespace SoliSocialWebApi.ViewModels.InstitutionManagement
{
    public class InstitutionMain
    {
        public Guid InstId { get; set; }
    }
}
