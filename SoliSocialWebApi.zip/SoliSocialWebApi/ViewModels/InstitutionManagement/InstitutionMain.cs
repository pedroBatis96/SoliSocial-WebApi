﻿using System;

namespace SoliSocialWebApi.ViewModels.InstitutionManagement
{
    public class InstitutionMain
    {
        public string InstId { get; set; }
    }
}
