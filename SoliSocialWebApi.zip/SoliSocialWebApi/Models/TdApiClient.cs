﻿using System;
using System.Collections.Generic;

namespace SoliSocialWebApi.Models
{
    public partial class TdApiClient
    {
        public string Id { get; set; }
        public string Nome { get; set; }
        public string Key { get; set; }
    }
}
